<h1 align="center"> DRAKEN MD  </h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;DRAKEN MD BUG;WHATSAPP+BUG+BOT;CREATED+BY+TOXXIC+BOY;RELEASED+20-07-24" alt="Typing SVG" /></a>
  </p>
    <img alt="TOXXIC-MD" width="830" height="950" src="https://telegra.ph/file/a17d08d830dff33ef69e7.png">
<p align="center">
<p align="center">
<a href="https://github.com/Toxic1239/Draken-Md-Bug"><img title="Author" src="https://img.shields.io/badge/Draken-Md?style=for-the-badge&logo=github"></a>
<p align="center">
<a href="https://github.com/Toxic1239/followers"><img title="Followers" src="https://img.shields.io/github/followers/Toxic1239?color=blue&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Draken-Md-Bug/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Toxic1239/Draken-Md-Star?color=red&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Draken-Md-Bug/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Toxic1239/Draken-Md-Bug?color=green&style=flat-square"></a>
<a href="https://github.com/Toxic1239/Draken-Md-Bug/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Toxic1239/Draken-Md-Bug?label=Watchers&color=yellow&style=flat-square"></a>

Draken Md is a bug bot designed to disable the account of Scammers all over the world use  reasonable

Yh i know my Readme Sucks and all Manage it 😶

1. Click on **[Fork](https://github.com/Toxic1239/Draken-Md-Bug/fork)** A must . Make sure to add a star 🌟 to encourage the developers.

**DEPLOYMENT PROCESS**
### DEPLOY ON REPLIT
IF YOU DON'T HAVE A REPLIT ACCOUNT CREATE ONE AND DEPLOY 
    <br>
    <a href='https://replit.com/github/Toxic1239/Draken-Md-Bug' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>


### DEPLOYMENT ON TERMUX

**Go to your termux and input this commands**
termux-setup-storage

apt update

apt upgrade

pkg update && pkg upgrade

pkg install bash

pkg install libwebp

pkg install git -y

pkg install nodejs -y

pkg install ffmpeg -y 

pkg install wget

pkg install imagemagick -y


If you see any question while upgrading with this options with Y for yes or N for no = Click yes or y

If you see any question while upgrading with this options with Y or n for default, = Click n for Default

6. After its done upgrading type or copy and paste:

git clone  (copy and paste your forked repo not mine to save your changes) 

7. After that type: 

cd DRAKEN-MD-BUG

8. after that type:

pkg install yarn

9. Then type:

yarn install 

10. After that type:

npm start 

11. It will ask you for your number type it with country code +
12. It will give you a pair code go and link it to your WhatsApp 
13. After linking
14. Bot Connected ⚡
15. Enjoy🤗

### REPORT ISSUES

if you're having any issues message me on
WhatsApp: (https://wa.me/33757054414) 

If the bot goes offline 
Just type cd and the bot name 
Then type npm start
It will come online

`Please Draken Md is just for fun, don't use it to harm innocent people`


## Contributions

Contributions to Draken MD are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request. <br>

   thanks to these people ;

   **Xeon** who made the base bot <br>


## License

The WhatsApp Bot Draken Md is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the WhatsApp Bot Toxxic Md to enhance your conversations and make your WhatsApp experience more interesting!

## Developers:

-TOXXIC MD
